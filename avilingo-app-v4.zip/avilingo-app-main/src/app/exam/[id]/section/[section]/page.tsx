'use client'
import { useEffect, useState, useRef } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { supabase } from '@/lib/supabase'

const ROLE_SECTION_ORDER: Record<string,string[]> = {
  general:      ['grammar','reading','listening','writing','speaking'],
  flight_deck:  ['grammar','reading','listening','writing','speaking'],
  cabin_crew:   ['grammar','listening','reading','speaking','writing'],
  atc:          ['grammar','listening','reading','speaking','writing'],
  maintenance:  ['grammar','reading','writing','listening','speaking'],
  ground_staff: ['grammar','reading','listening','writing','speaking'],
}

const S = {
  grammar:   { color: '#2563eb', bg: '#dbeafe', dark: '#1d4ed8', label: 'Grammar',   icon: '📖', emoji: 'G' },
  reading:   { color: '#16a34a', bg: '#dcfce7', dark: '#15803d', label: 'Reading',   icon: '🧠', emoji: 'R' },
  writing:   { color: '#7c3aed', bg: '#ede9fe', dark: '#6d28d9', label: 'Writing',   icon: '✏️', emoji: 'W' },
  speaking:  { color: '#dc2626', bg: '#fee2e2', dark: '#b91c1c', label: 'Speaking',  icon: '🎤', emoji: 'S' },
  listening: { color: '#ea580c', bg: '#ffedd5', dark: '#c2410c', label: 'Listening', icon: '👂', emoji: 'L' },
}

const MIN_SPEAKING_SECS = 30

export default function ExamSectionPage() {
  const router = useRouter()
  const params = useParams()
  const examId = params.id as string
  const section = params.section as string

  const [exam, setExam] = useState<any>(null)
  const [questions, setQuestions] = useState<any[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<string,string>>({})
  const [loading, setLoading] = useState(true)
  const [timeLeft, setTimeLeft] = useState(0)
  const [qTimeLeft, setQTimeLeft] = useState(0)
  const [strikes, setStrikes] = useState(0)
  const [showStrikeModal, setShowStrikeModal] = useState(false)
  const [showTransitionModal, setShowTransitionModal] = useState(false)
  const [saving, setSaving] = useState(false)

  // Section prep
  const [showPrep, setShowPrep] = useState(true)
  const [prepLeft, setPrepLeft] = useState(45)
  const [prepReady, setPrepReady] = useState(false)
  const [prepTotal, setPrepTotal] = useState(45)

  // Writing
  const [wordCount, setWordCount] = useState(0)
  const [writingLocked, setWritingLocked] = useState(false)

  // Speaking
  const [recState, setRecState] = useState<'idle'|'recording'|'recorded'>('idle')
  const [recTime, setRecTime] = useState(0)
  const [attempts, setAttempts] = useState(0)

  // Listening
  const [listenState, setListenState] = useState<'idle'|'playing'|'done'>('idle')

  const timerRef = useRef<any>(null)
  const qTimerRef = useRef<any>(null)
  const prepTimerRef = useRef<any>(null)
  const recTimerRef = useRef<any>(null)
  const listenTimerRef = useRef<any>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const streamRef = useRef<MediaStream|null>(null)
  const audioRef = useRef<HTMLAudioElement>(null)

  useEffect(() => { loadExam() }, [])

  // PiP webcam
  useEffect(() => {
    let active = true
    navigator.mediaDevices.getUserMedia({ video: true, audio: false })
      .then(s => { if (!active) { s.getTracks().forEach(t=>t.stop()); return }; streamRef.current=s; if(videoRef.current) videoRef.current.srcObject=s })
      .catch(()=>{})
    return () => { active=false; streamRef.current?.getTracks().forEach(t=>t.stop()) }
  }, [])

  // When exam loads, sync prep duration from template
  useEffect(() => {
    if (!exam) return
    const tmplData = exam.exam_templates
    const prepKey = 'prep_' + section
    const cfg = tmplData?.[prepKey]
    const secs = cfg?.seconds ?? 45
    setPrepLeft(secs)
    setPrepTotal(secs)
  }, [exam])

  // Section prep countdown
  useEffect(() => {
    if (!showPrep) return
    prepTimerRef.current = setInterval(() => {
      setPrepLeft(t => {
        if (t <= 1) { clearInterval(prepTimerRef.current); setShowPrep(false); return 0 }
        // "I'm ready" unlocks after first 5 seconds have elapsed
        setPrepReady(prev => prev || t <= (prepTotal - 5))
        return t - 1
      })
    }, 1000)
    return () => clearInterval(prepTimerRef.current)
  }, [showPrep, prepTotal])

  // Reset per-question state
  useEffect(() => {
    setWordCount(0); setWritingLocked(false)
    setRecState('idle'); setRecTime(0); setAttempts(0)
    setListenState('idle')
    clearInterval(recTimerRef.current); clearInterval(listenTimerRef.current); clearInterval(qTimerRef.current)
  }, [currentIndex, showPrep])

  // Writing per-question timer
  useEffect(() => {
    if (!loading && section === 'writing' && !showPrep && exam) {
      const mins = exam.exam_templates?.writing_timer_mins || 3.5
      const secs = Math.round(mins * 60)
      setQTimeLeft(secs)
      clearInterval(qTimerRef.current)
      qTimerRef.current = setInterval(() => {
        setQTimeLeft(t => {
          if (t <= 1) { clearInterval(qTimerRef.current); setWritingLocked(true); handleNextQuestion(true); return 0 }
          return t - 1
        })
      }, 1000)
    }
  }, [currentIndex, loading, showPrep])

  useEffect(() => {
    document.addEventListener('visibilitychange', onVisibility)
    document.addEventListener('contextmenu', e=>e.preventDefault())
    document.addEventListener('keydown', onKey)
    window.addEventListener('blur', onBlur)
    return () => {
      document.removeEventListener('visibilitychange', onVisibility)
      document.removeEventListener('keydown', onKey)
      window.removeEventListener('blur', onBlur)
    }
  }, [strikes])

  function onVisibility() { if (document.hidden) triggerStrike('tab_switch') }
  function onBlur() { triggerStrike('window_blur') }
  function onKey(e: KeyboardEvent) { if ((e.ctrlKey||e.metaKey) && ['c','v','x'].includes(e.key)) e.preventDefault() }

  async function triggerStrike(type: string) {
    const n = strikes + 1; setStrikes(n)
    await supabase.from('violations').insert({ exam_id: examId, type, strike_number: n })
    if (n >= 3) { await supabase.from('exams').update({ status: 'invalidated' }).eq('id', examId); router.push(`/exam/${examId}/invalidated`); return }
    setShowStrikeModal(true)
  }

  async function loadExam() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { router.push('/login'); return }
    const { data: examData } = await supabase.from('exams').select('*,exam_templates(*)').eq('id', examId).eq('candidate_id', user.id).single()
    if (!examData || examData.status === 'invalidated') { router.push('/exam'); return }
    setExam(examData)
    const tmpl = examData.exam_templates
    const count = tmpl[`${section}_count`] || 10
    const { data: existing } = await supabase.from('exam_question_sets').select('*,questions(*)').eq('exam_id', examId).eq('section', section).order('question_order')
    let qs = existing || []
    if (!qs.length) {
      const { data: pool } = await supabase.from('questions').select('*').eq('section', section).eq('active', true).eq('is_latest', true).limit(count * 3)
      if (!pool?.length) { setLoading(false); return }
      const shuffled = pool.sort(()=>Math.random()-.5).slice(0, count)
      const inserts = shuffled.map((q,i) => ({ exam_id: examId, question_id: q.id, section, question_order: i }))
      await supabase.from('exam_question_sets').insert(inserts)
      qs = inserts.map((ins,i) => ({ ...ins, questions: shuffled[i] }))
    }
    setQuestions(qs.map((q:any) => q.questions))
    const totalMins = tmpl.time_limit_mins || 90
    setTimeLeft(totalMins * 60)
    setLoading(false)
    startGlobalTimer()
  }

  function startGlobalTimer() {
    timerRef.current = setInterval(() => {
      setTimeLeft(t => { if (t<=1) { clearInterval(timerRef.current); handleSectionComplete(); return 0 }; return t-1 })
    }, 1000)
  }

  function fmt(s: number) { return `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}` }

  function handleAnswer(qid: string, answer: string) {
    setAnswers(prev => ({...prev, [qid]: answer}))
    setSaving(true); setTimeout(() => setSaving(false), 1200)
    if (section === 'writing') setWordCount(answer.trim().split(/\s+/).filter(Boolean).length)
  }

  async function saveAnswer(qid: string, answer: string) {
    await supabase.from('exam_answers').upsert({ exam_id: examId, question_id: qid, section, answer, time_spent_ms: 0 }, { onConflict: 'exam_id,question_id' })
  }

  function handleNextQuestion(autoAdvance = false) {
    const minWords = exam?.exam_templates?.writing_min_words || 40
    if (!autoAdvance && section === 'writing' && wordCount < minWords) return
    if (!autoAdvance && section === 'speaking' && recState !== 'recorded') return
    const q = questions[currentIndex]
    if (q) saveAnswer(q.id, answers[q.id] || '')
    if (currentIndex < questions.length - 1) setCurrentIndex(i => i+1)
    else setShowTransitionModal(true)
  }

  async function handleSectionComplete() {
    setSaving(true)
    for (const q of questions) await saveAnswer(q.id, answers[q.id] || '')
    clearInterval(timerRef.current); clearInterval(qTimerRef.current)
    if (['grammar','reading','listening'].includes(section)) {
      for (const q of questions) {
        const answer = answers[q.id] || ''
        const score = q.correct_answer?.trim().toLowerCase() === answer.trim().toLowerCase() ? 1 : 0
        await supabase.from('exam_answers').upsert({ exam_id: examId, question_id: q.id, section, answer, auto_score: score }, { onConflict: 'exam_id,question_id' })
      }
    }
    setSaving(false)
    const tmpl = exam?.exam_templates
    const role = tmpl?.role_profile || 'general'
    const order = (ROLE_SECTION_ORDER[role]||ROLE_SECTION_ORDER.general).filter((s:string) => (tmpl?.[`${s}_count`]||0) > 0)
    const next = order[order.indexOf(section) + 1]
    if (next) { setShowTransitionModal(false); router.push(`/exam/${examId}/section/${next}`) }
    else { await supabase.from('exams').update({ status: 'completed', completed_at: new Date().toISOString() }).eq('id', examId); router.push(`/exam/${examId}/complete`) }
  }

  function startSpeaking() {
    const max = exam?.exam_templates?.speaking_attempts || 3
    if (attempts >= max) return
    setRecState('recording'); setRecTime(0); setAttempts(a => a+1)
    clearInterval(recTimerRef.current)
    recTimerRef.current = setInterval(() => {
      setRecTime(t => { if (t >= 119) { clearInterval(recTimerRef.current); stopSpeaking(); return 120 }; return t+1 })
    }, 1000)
  }

  function stopSpeaking() {
    clearInterval(recTimerRef.current); setRecState('recorded')
    const q = questions[currentIndex]; if (q) handleAnswer(q.id, 'recorded')
  }

  function playListening() {
    if (listenState !== 'idle') return
    setListenState('playing')
    if (audioRef.current) { audioRef.current.play(); return }
    listenTimerRef.current = setTimeout(() => setListenState('done'), 4000)
  }

  const sec = S[section as keyof typeof S] || S.grammar
  const tmpl = exam?.exam_templates
  const role = tmpl?.role_profile || 'general'
  const order = !loading ? (ROLE_SECTION_ORDER[role]||ROLE_SECTION_ORDER.general).filter((s:string)=>(tmpl?.[`${s}_count`]||0)>0) : []
  const secIdx = order.indexOf(section)
  const maxAttempts = tmpl?.speaking_attempts || 3
  const minWords = tmpl?.writing_min_words || 40
  const canNext = section === 'writing' ? wordCount >= minWords : section === 'speaking' ? recState === 'recorded' : true
  const currentQ = questions[currentIndex]

  // ── font & base styles ──────────────────────────────────────────────────
  const font = "'DM Sans', sans-serif"

  if (loading) return (
    <div style={{minHeight:'100vh',background:'#f3f4f6',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:font}}>
      <div style={{color:'#374151'}}>Loading questions…</div>
    </div>
  )

  if (!currentQ) return (
    <div style={{minHeight:'100vh',background:'#f3f4f6',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:font}}>
      <div style={{textAlign:'center'}}>
        <div style={{marginBottom:'16px',color:'#374151'}}>No questions available for this section.</div>
        <button onClick={handleSectionComplete} style={{padding:'12px 28px',borderRadius:'50px',border:'none',background:'#2563eb',color:'#fff',cursor:'pointer',fontFamily:font,fontWeight:600}}>Continue →</button>
      </div>
    </div>
  )

  // ── SECTION PREP SCREEN ─────────────────────────────────────────────────
  if (showPrep) {
    const prepPct = prepTotal > 0 ? ((prepTotal - prepLeft) / prepTotal) * 100 : 100
    // Load prep config from template (set by admin), fall back to sensible defaults
    const prepKey = ('prep_' + section) as string
    const prepCfg = tmpl?.[prepKey] || {}
    const prepSeconds = prepCfg.seconds ?? 45
    const sectionBullets: string[] = prepCfg.bullets?.length
      ? prepCfg.bullets
      : {
          grammar:   ['The grammar section includes multiple-choice questions.','Read each question carefully and select the best answer.','There are no penalties for wrong answers.'],
          reading:   ['Read the passage carefully before answering.','Each question has only one correct answer.','There are no penalties for incorrect answers.'],
          writing:   [`Write at least ${minWords} words per question.`,`You have ${tmpl?.writing_timer_mins||3.5} minutes per question.`,'Copy/paste is disabled. Write in full sentences.'],
          speaking:  [`You have ${maxAttempts} recording attempts per question.`,`Speak for at least ${MIN_SPEAKING_SECS} seconds minimum.`,'Do not use written texts or AI-generated content.'],
          listening: ['Each audio clip plays exactly once.','Listen carefully — you cannot replay it.','There are no penalties for wrong answers.'],
        }[section] || []
    return (
      <div style={{minHeight:'100vh',background:'#f3f4f6',display:'flex',flexDirection:'column',fontFamily:font}}>
        {/* PiP */}
        <div style={{position:'fixed',top:'16px',left:'16px',zIndex:50,width:'64px',height:'64px',borderRadius:'50%',overflow:'hidden',border:'2px solid #d1d5db',background:'#9ca3af'}}>
          <video ref={videoRef} autoPlay muted playsInline style={{width:'100%',height:'100%',objectFit:'cover',transform:'scaleX(-1)'}} />
          <span style={{position:'absolute',bottom:0,left:'50%',transform:'translateX(-50%) translateY(1px)',background:'#22c55e',color:'#fff',fontSize:'8px',fontWeight:800,padding:'1px 5px',borderRadius:'100px'}}>LIVE</span>
        </div>

        {/* Top bar */}
        <div style={{background:'#fff',borderBottom:'1px solid #e5e7eb',padding:'14px 32px',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <span style={{fontSize:'13px',color:'#6b7280',fontWeight:600}}>Section Transition</span>
          <span style={{padding:'4px 14px',borderRadius:'50px',border:'1px solid #e5e7eb',fontSize:'12px',color:'#6b7280',fontWeight:600}}>Preparation Time</span>
        </div>

        <div style={{flex:1,display:'flex',alignItems:'center',justifyContent:'center',padding:'40px 20px'}}>
          <div style={{background:'#fff',borderRadius:'24px',padding:'48px',maxWidth:'600px',width:'100%',boxShadow:'0 10px 15px rgba(0,0,0,.1)',textAlign:'center'}}>
            <div style={{width:'72px',height:'72px',borderRadius:'50%',background:sec.color,display:'flex',alignItems:'center',justifyContent:'center',fontSize:'28px',margin:'0 auto 20px'}}>
              {sec.icon}
            </div>
            <h2 style={{fontSize:'26px',fontWeight:800,color:sec.color,marginBottom:'28px'}}>{sec.label} section is starting</h2>
            <ul style={{textAlign:'left',marginBottom:'32px',listStyle:'none',display:'flex',flexDirection:'column',gap:'8px'}}>
              {sectionBullets.map((b,i) => (
                <li key={i} style={{display:'flex',gap:'8px',fontSize:'14px',color:'#4b5563',lineHeight:1.6}}>
                  <span style={{color:sec.color,fontWeight:700,flexShrink:0}}>•</span>{b}
                </li>
              ))}
            </ul>
            <div style={{fontSize:'56px',fontWeight:800,color:sec.color,lineHeight:1,marginBottom:'4px'}}>{fmt(prepLeft)}</div>
            <div style={{fontSize:'13px',color:'#9ca3af',marginBottom:'16px'}}>Time Left</div>
            <div style={{height:'6px',background:'#e5e7eb',borderRadius:'3px',overflow:'hidden',marginBottom:'24px'}}>
              <div style={{height:'100%',background:sec.color,borderRadius:'3px',width:`${prepPct}%`,transition:'width 1s linear'}} />
            </div>
            {prepReady ? (
              <button onClick={() => { clearInterval(prepTimerRef.current); setShowPrep(false) }}
                style={{padding:'14px 40px',borderRadius:'50px',border:'none',background:sec.color,color:'#fff',fontSize:'15px',fontWeight:700,cursor:'pointer',fontFamily:font,transition:'all .2s'}}>
                I'm Ready — Start Now →
              </button>
            ) : (
              <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:'8px',color:'#9ca3af',fontSize:'13px'}}>
                <div style={{width:'14px',height:'14px',border:'2px solid #e5e7eb',borderTopColor:'#9ca3af',borderRadius:'50%',animation:'spin 1s linear infinite'}} />
                Please read the instructions…
              </div>
            )}
          </div>
        </div>
        <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      </div>
    )
  }

  // ── EXAM SCREEN ─────────────────────────────────────────────────────────
  const completedSections = order.slice(0, secIdx)

  return (
    <div style={{minHeight:'100vh',background:'#f3f4f6',display:'flex',flexDirection:'column',fontFamily:font,userSelect:'none'}}>

      {/* Strike modal */}
      {showStrikeModal && (
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.5)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center'}}>
          <div style={{background:'#fff',borderRadius:'24px',padding:'32px',maxWidth:'420px',width:'90%',border:'2px solid #fde68a',boxShadow:'0 20px 25px rgba(0,0,0,.15)'}}>
            <div style={{textAlign:'center',marginBottom:'16px',fontSize:'36px'}}>⚠️</div>
            <h3 style={{textAlign:'center',fontSize:'20px',fontWeight:800,marginBottom:'8px'}}>Warning — Strike {strikes} of 3</h3>
            <p style={{fontSize:'14px',color:'#6b7280',textAlign:'center',marginBottom:'20px'}}>Focus violation detected. {3-strikes} strike{3-strikes!==1?'s':''} remaining before automatic invalidation.</p>
            <button onClick={()=>setShowStrikeModal(false)} style={{width:'100%',padding:'12px',borderRadius:'50px',border:'none',background:'#2563eb',color:'#fff',fontSize:'15px',fontWeight:600,cursor:'pointer',fontFamily:font}}>I Understand — Continue</button>
          </div>
        </div>
      )}

      {/* Transition modal */}
      {showTransitionModal && (
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.5)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center'}}>
          <div style={{background:'#fff',borderRadius:'24px',padding:'32px',maxWidth:'480px',width:'90%',boxShadow:'0 20px 25px rgba(0,0,0,.15)'}}>
            <div style={{display:'flex',alignItems:'center',gap:'12px',marginBottom:'16px'}}>
              <span style={{fontSize:'24px'}}>⚠️</span>
              <div style={{fontSize:'18px',fontWeight:700}}>Section Transition</div>
            </div>
            <p style={{fontSize:'14px',color:'#6b7280',marginBottom:'12px'}}>You are about to permanently lock the <strong style={{textTransform:'capitalize'}}>{section}</strong> section.</p>
            <div style={{background:'#fffbeb',border:'1px solid #fde68a',borderRadius:'10px',padding:'12px 14px',marginBottom:'20px',fontSize:'13px',color:'#92400e',display:'flex',gap:'8px'}}>
              <span>⚠️</span><span>You cannot return to this section after confirming.</span>
            </div>
            <div style={{display:'flex',gap:'10px'}}>
              <button onClick={()=>setShowTransitionModal(false)} style={{flex:1,padding:'12px',borderRadius:'50px',border:'2px solid #e5e7eb',background:'#fff',color:'#2563eb',fontSize:'14px',fontWeight:600,cursor:'pointer',fontFamily:font}}>Cancel</button>
              <button onClick={handleSectionComplete} disabled={saving} style={{flex:1,padding:'12px',borderRadius:'50px',border:'none',background:'#16a34a',color:'#fff',fontSize:'14px',fontWeight:600,cursor:'pointer',fontFamily:font}}>
                {saving ? 'Saving…' : 'Understood, Continue →'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top bar */}
      <div style={{background:'#fff',borderBottom:'1px solid #e5e7eb',padding:'0 20px',height:'52px',display:'flex',alignItems:'center',justifyContent:'space-between',position:'sticky',top:0,zIndex:50}}>
        <div style={{display:'flex',alignItems:'center',gap:'12px'}}>
          <span style={{padding:'4px 12px',borderRadius:'50px',background:sec.color,color:'#fff',fontSize:'12px',fontWeight:700}}>{sec.label}</span>
          <span style={{fontSize:'13px',fontWeight:700,color:'#374151'}}>{sec.label} - Question {currentIndex+1} / {questions.length}</span>
          <span style={{fontSize:'12px',color:'#9ca3af'}}>Overall: {currentIndex+1} / {questions.length}</span>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:'12px'}}>
          {section === 'writing' && (
            <span style={{fontSize:'13px',fontWeight:700,color:qTimeLeft<60?'#dc2626':'#f59e0b'}}>⏱ {fmt(qTimeLeft)}</span>
          )}
          <div style={{display:'flex',alignItems:'center',gap:'6px',padding:'6px 14px',background:'#fffbeb',border:'1px solid #fde68a',borderRadius:'50px',fontSize:'14px',fontWeight:700,color:'#92400e',fontFamily:"'DM Mono',monospace"}}>
            ⏱ {fmt(timeLeft)}
          </div>
          {saving && <div style={{display:'flex',alignItems:'center',gap:'6px',fontSize:'12px',color:'#9ca3af'}}><div style={{width:'12px',height:'12px',border:'2px solid #e5e7eb',borderTopColor:'#2563eb',borderRadius:'50%',animation:'spin 1s linear infinite'}} />Saving…</div>}
          {strikes > 0 && <span style={{fontSize:'12px',fontWeight:700,color:'#dc2626'}}>⚠️ {strikes}/3</span>}
          <span style={{padding:'4px 12px',borderRadius:'50px',border:'1px solid #e5e7eb',fontSize:'12px',color:'#9ca3af',fontWeight:600}}>In Progress</span>
          {/* Section progress dots */}
          <div style={{display:'flex',gap:'4px'}}>
            {order.map((s:string,i:number) => <div key={s} style={{width:'28px',height:'4px',borderRadius:'2px',background:i<secIdx?S[s as keyof typeof S].color:s===section?S[s as keyof typeof S].color:'#e5e7eb',opacity:i<secIdx?.6:1}} />)}
          </div>
          {/* PiP */}
          <div style={{width:'36px',height:'36px',borderRadius:'50%',overflow:'hidden',border:'2px solid #e5e7eb',background:'#9ca3af',position:'relative',flexShrink:0}}>
            <video ref={videoRef} autoPlay muted playsInline style={{width:'100%',height:'100%',objectFit:'cover',transform:'scaleX(-1)'}} />
            <span style={{position:'absolute',bottom:0,left:'50%',transform:'translateX(-50%) translateY(1px)',background:'#22c55e',color:'#fff',fontSize:'7px',fontWeight:800,padding:'1px 3px',borderRadius:'100px'}}>LIVE</span>
          </div>
        </div>
      </div>

      {/* Progress bar */}
      <div style={{height:'3px',background:'#e5e7eb'}}>
        <div style={{height:'100%',background:sec.color,width:`${((currentIndex+1)/questions.length)*100}%`,transition:'width .3s'}} />
      </div>

      {/* Breadcrumb */}
      {completedSections.length > 0 && (
        <div style={{background:'#fff',borderBottom:'1px solid #f3f4f6',padding:'8px 20px',display:'flex',alignItems:'center',gap:'6px',fontSize:'12px',color:'#9ca3af'}}>
          Completed:{' '}
          {completedSections.map((s:string,i:number) => (
            <span key={s}>
              <span style={{padding:'2px 8px',borderRadius:'50px',background:S[s as keyof typeof S].color,color:'#fff',fontSize:'11px',fontWeight:700}}>{S[s as keyof typeof S].label}</span>
              {i < completedSections.length-1 && <span style={{color:'#d1d5db',margin:'0 4px'}}>→</span>}
            </span>
          ))}
          <span style={{color:'#d1d5db',margin:'0 4px'}}>→</span>
          <span style={{fontWeight:700,color:'#374151'}}>Now: {sec.label}</span>
        </div>
      )}

      {/* Question body */}
      <div style={{flex:1,padding:'24px 20px',maxWidth:'900px',margin:'0 auto',width:'100%'}}>

        {/* Grammar / Reading */}
        {(section === 'grammar' || section === 'reading') && (
          <div style={{background:'#fff',borderRadius:'16px',padding:'24px',border:'1px solid #e5e7eb',boxShadow:'0 1px 3px rgba(0,0,0,.08)'}}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'16px'}}>
              <div style={{fontSize:'15px',fontWeight:700}}>{sec.icon} <span style={{color:sec.color}}>{sec.label} - Question {currentIndex+1}</span></div>
              <button onClick={()=>{const q=questions[currentIndex];if(q)setAnswers(p=>({...p,[q.id]:''}))}} style={{padding:'4px 12px',borderRadius:'50px',border:'1px solid #e5e7eb',background:'#fff',fontSize:'12px',color:'#9ca3af',cursor:'pointer',fontFamily:font}}>🗑️ Clear Answer</button>
            </div>
            {section === 'reading' && currentQ.passage && (
              <div style={{background:'#f9fafb',borderRadius:'10px',padding:'14px 16px',fontSize:'14px',color:'#4b5563',lineHeight:1.7,marginBottom:'14px',border:'1px solid #e5e7eb'}}>{currentQ.passage}</div>
            )}
            <p style={{fontSize:'16px',color:'#111827',lineHeight:1.7,marginBottom:'16px',fontWeight:500}}>{currentQ.content}</p>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'10px'}}>
              {['A','B','C','D'].map((opt) => {
                const isSelected = answers[currentQ.id] === opt
                return (
                  <button key={opt} onClick={()=>handleAnswer(currentQ.id, opt)}
                    style={{padding:'14px 18px',borderRadius:'12px',border:`2px solid ${isSelected?sec.color:'#e5e7eb'}`,background:isSelected?sec.bg:'#fff',color:isSelected?sec.dark:'#374151',fontSize:'14px',cursor:'pointer',fontFamily:font,textAlign:'left',display:'flex',gap:'12px',alignItems:'center',transition:'all .15s',fontWeight:isSelected?600:400}}>
                    <div style={{width:'20px',height:'20px',borderRadius:'50%',border:`2px solid ${isSelected?sec.color:'#d1d5db'}`,background:isSelected?sec.color:'transparent',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                      {isSelected && <div style={{width:'6px',height:'6px',borderRadius:'50%',background:'#fff'}} />}
                    </div>
                    Option {opt}
                  </button>
                )
              })}
            </div>
          </div>
        )}

        {/* Listening */}
        {section === 'listening' && (
          <div style={{background:'#fff',borderRadius:'16px',padding:'24px',border:'1px solid #e5e7eb',boxShadow:'0 1px 3px rgba(0,0,0,.08)'}}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'16px'}}>
              <div style={{fontSize:'15px',fontWeight:700}}>👂 <span style={{color:sec.color}}>Listening - Question {currentIndex+1}</span></div>
              <button onClick={()=>{const q=questions[currentIndex];if(q)setAnswers(p=>({...p,[q.id]:''}))}} style={{padding:'4px 12px',borderRadius:'50px',border:'1px solid #e5e7eb',background:'#fff',fontSize:'12px',color:'#9ca3af',cursor:'pointer',fontFamily:font}}>🗑️ Clear Answer</button>
            </div>
            {currentQ.audio_url && (
              <audio ref={audioRef} src={currentQ.audio_url} onEnded={()=>setListenState('done')} style={{display:'none'}} />
            )}
            {/* Audio player */}
            <div style={{background:'#f9fafb',border:'1px solid #e5e7eb',borderRadius:'12px',padding:'14px 16px',display:'flex',alignItems:'center',gap:'14px',marginBottom:'14px'}}>
              <button onClick={playListening} disabled={listenState!=='idle'}
                style={{width:'48px',height:'48px',borderRadius:'50%',border:'none',background:listenState==='idle'?sec.color:'#e5e7eb',color:'#fff',fontSize:'18px',cursor:listenState==='idle'?'pointer':'not-allowed',flexShrink:0,display:'flex',alignItems:'center',justifyContent:'center'}}>
                {listenState==='playing'?'⏸':'▶'}
              </button>
              <div style={{flex:1,display:'flex',alignItems:'center',gap:'2px',height:'36px'}}>
                {Array.from({length:30},(_,i) => (
                  <div key={i} style={{width:'4px',borderRadius:'2px',background:listenState==='playing'?sec.color:listenState==='done'?'#9ca3af':'#d1d5db',height:listenState==='playing'?`${8+Math.sin(i)*8+Math.random()*6}px`:'8px',transition:'height .1s'}} />
                ))}
              </div>
              <div style={{textAlign:'right'}}>
                <div style={{fontSize:'12px',color:'#6b7280',whiteSpace:'nowrap'}}>{currentQ.audioLabel||'🔊 Audio'}</div>
                {listenState==='done' && <div style={{fontSize:'11px',fontWeight:700,color:'#dc2626',marginTop:'2px'}}>🔒 Played once — locked</div>}
                {listenState==='idle' && <div style={{fontSize:'11px',color:'#9ca3af',marginTop:'2px'}}>▶ Play once only</div>}
              </div>
            </div>
            <p style={{fontSize:'15px',color:'#111827',marginBottom:'14px',fontWeight:500}}>{currentQ.content}</p>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'10px'}}>
              {['A','B','C','D'].map((opt) => {
                const isSelected = answers[currentQ.id] === opt
                return (
                  <button key={opt} onClick={()=>handleAnswer(currentQ.id, opt)}
                    style={{padding:'14px 18px',borderRadius:'12px',border:`2px solid ${isSelected?sec.color:'#e5e7eb'}`,background:isSelected?sec.bg:'#fff',color:isSelected?sec.dark:'#374151',fontSize:'14px',cursor:'pointer',fontFamily:font,textAlign:'left',display:'flex',gap:'12px',alignItems:'center',transition:'all .15s',fontWeight:isSelected?600:400}}>
                    <div style={{width:'20px',height:'20px',borderRadius:'50%',border:`2px solid ${isSelected?sec.color:'#d1d5db'}`,background:isSelected?sec.color:'transparent',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                      {isSelected && <div style={{width:'6px',height:'6px',borderRadius:'50%',background:'#fff'}} />}
                    </div>
                    Option {opt}
                  </button>
                )
              })}
            </div>
          </div>
        )}

        {/* Writing */}
        {section === 'writing' && (
          <div style={{background:'#fff',borderRadius:'16px',padding:'24px',border:'1px solid #e5e7eb',boxShadow:'0 1px 3px rgba(0,0,0,.08)'}}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'16px'}}>
              <div style={{fontSize:'15px',fontWeight:700}}>✏️ <span style={{color:sec.color}}>Writing Section - Question {currentIndex+1}</span></div>
              <div style={{padding:'6px 14px',borderRadius:'50px',background:qTimeLeft<=30?'#dc2626':sec.color,color:'#fff',fontSize:'13px',fontWeight:700,fontFamily:"'DM Mono',monospace"}}>⏱ {fmt(qTimeLeft)}</div>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'20px'}}>
              <div style={{display:'flex',flexDirection:'column',gap:'12px'}}>
                <p style={{fontSize:'13px',color:'#6b7280'}}>Write a composition of at least <strong>{minWords}</strong> words:</p>
                <div style={{borderRadius:'12px',overflow:'hidden',border:'1px solid #dbeafe'}}>
                  <div style={{padding:'8px 12px',background:'#2563eb',color:'#fff',fontSize:'12px',fontWeight:700}}>Question</div>
                  <div style={{padding:'12px 14px',background:'#eff6ff',fontSize:'13px',color:'#374151',lineHeight:1.6,fontStyle:'italic'}}>{currentQ.content}</div>
                </div>
                <div style={{background:'#eff6ff',border:'1px solid #dbeafe',borderRadius:'12px',padding:'12px 14px',fontSize:'12px',color:'#6b7280'}}>
                  ℹ️ You have {fmt(qTimeLeft)} remaining. Minimum {minWords} words required to proceed.
                </div>
              </div>
              <div style={{display:'flex',flexDirection:'column'}}>
                <textarea
                  value={answers[currentQ.id]||''}
                  onChange={e=>{if(!writingLocked){handleAnswer(currentQ.id,e.target.value)}}}
                  disabled={writingLocked}
                  placeholder="Write your composition here…"
                  onCopy={e=>e.preventDefault()} onPaste={e=>e.preventDefault()}
                  style={{flex:1,minHeight:'200px',padding:'14px',border:`2px solid ${wordCount>=minWords?'#16a34a':'#e5e7eb'}`,borderRadius:'12px',fontSize:'14px',fontFamily:font,lineHeight:1.7,outline:'none',resize:'vertical',background:writingLocked?'#f9fafb':'#fff',color:writingLocked?'#9ca3af':'#111827',cursor:writingLocked?'not-allowed':'text',transition:'border-color .2s'}}
                />
                {writingLocked && <div style={{marginTop:'8px',padding:'10px 14px',background:'#f0fdf4',border:'1px solid #86efac',borderRadius:'10px',fontSize:'12px',color:'#15803d',fontWeight:600}}>✅ Saved — no longer editable</div>}
                <div style={{marginTop:'10px'}}>
                  <div style={{display:'flex',justifyContent:'space-between',marginBottom:'4px'}}>
                    <span style={{fontSize:'12px',color:wordCount>=minWords?'#16a34a':'#9ca3af',fontWeight:wordCount>=minWords?700:400}}>{wordCount} words {wordCount>=minWords?'✓ Minimum met':''}</span>
                    <span style={{fontSize:'12px',color:'#9ca3af'}}>Min: {minWords}</span>
                  </div>
                  <div style={{height:'4px',background:'#e5e7eb',borderRadius:'2px',overflow:'hidden'}}>
                    <div style={{height:'100%',background:wordCount>=minWords?'#16a34a':'#f59e0b',borderRadius:'2px',width:`${Math.min(100,(wordCount/minWords)*100)}%`,transition:'width .3s'}} />
                  </div>
                  {!writingLocked && wordCount < minWords && (
                    <p style={{marginTop:'6px',fontSize:'12px',color:'#f59e0b',fontWeight:600}}>Write {minWords-wordCount} more word{minWords-wordCount!==1?'s':''} to unlock Next</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Speaking */}
        {section === 'speaking' && (
          <div style={{background:'#fff',borderRadius:'16px',padding:'24px',border:'1px solid #e5e7eb',boxShadow:'0 1px 3px rgba(0,0,0,.08)'}}>
            <div style={{fontSize:'15px',fontWeight:700,marginBottom:'16px'}}>🎤 <span style={{color:sec.color}}>Speaking Section - Question {currentIndex+1}</span></div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'20px'}}>
              <div style={{display:'flex',flexDirection:'column',gap:'12px'}}>
                <div style={{borderRadius:'12px',overflow:'hidden',border:'1px solid #fecaca'}}>
                  <div style={{padding:'8px 12px',background:'#dc2626',color:'#fff',fontSize:'12px',fontWeight:700}}>Question</div>
                  <div style={{padding:'12px 14px',background:'#fff1f2',fontSize:'13px',color:'#374151',lineHeight:1.6}}>{currentQ.content}</div>
                </div>
                <div style={{background:'#eff6ff',border:'1px solid #dbeafe',borderRadius:'12px',padding:'12px 14px',fontSize:'12px',color:'#6b7280'}}>
                  📝 Press Start, speak clearly for at least {MIN_SPEAKING_SECS}s, then press Stop.
                </div>
                <div style={{background:'#fffbeb',border:'1px solid #fde68a',borderRadius:'12px',padding:'12px 14px',fontSize:'12px',color:'#92400e'}}>
                  ⚠️ Max {maxAttempts} attempts. Each recording uses one attempt.
                </div>
              </div>
              <div style={{background:'#f9fafb',border:'1px solid #e5e7eb',borderRadius:'14px',padding:'20px'}}>
                {/* Attempt dots */}
                <div style={{display:'flex',alignItems:'center',gap:'10px',marginBottom:'16px'}}>
                  <span style={{fontSize:'13px',fontWeight:700,color:'#374151'}}>Voice Recording</span>
                  <div style={{display:'flex',gap:'6px',marginLeft:'auto'}}>
                    {Array.from({length:maxAttempts},(_,i) => (
                      <div key={i} style={{width:'16px',height:'16px',borderRadius:'50%',border:`2px solid ${i<attempts?sec.color:'#d1d5db'}`,background:i<attempts?sec.color:'transparent',display:'flex',alignItems:'center',justifyContent:'center'}}>
                        {i<attempts && <div style={{width:'5px',height:'5px',borderRadius:'50%',background:'#fff'}} />}
                      </div>
                    ))}
                  </div>
                  <span style={{fontSize:'12px',color:'#9ca3af'}}>{attempts}/{maxAttempts}</span>
                  {recState==='recorded'
                    ? <span style={{padding:'3px 10px',borderRadius:'50px',background:'#fffbeb',border:'1px solid #fde68a',fontSize:'11px',fontWeight:700,color:'#92400e'}}>⚠️ Recorded</span>
                    : <span style={{padding:'3px 10px',borderRadius:'50px',background:'#f3f4f6',fontSize:'11px',color:'#9ca3af',fontWeight:600}}>No recording</span>}
                </div>

                {recState==='idle' && attempts < maxAttempts && (
                  <button onClick={startSpeaking} style={{width:'100%',padding:'12px',borderRadius:'50px',border:'none',background:'#2563eb',color:'#fff',fontSize:'14px',fontWeight:700,cursor:'pointer',fontFamily:font,marginBottom:'12px'}}>
                    🎙️ Start Recording
                  </button>
                )}

                {recState==='recording' && (
                  <>
                    <button onClick={recTime>=MIN_SPEAKING_SECS?stopSpeaking:undefined} disabled={recTime<MIN_SPEAKING_SECS}
                      style={{width:'100%',padding:'12px',borderRadius:'50px',border:'none',background:recTime>=MIN_SPEAKING_SECS?'#dc2626':'#9ca3af',color:'#fff',fontSize:'14px',fontWeight:700,cursor:recTime>=MIN_SPEAKING_SECS?'pointer':'not-allowed',fontFamily:font,marginBottom:'8px'}}>
                      {recTime>=MIN_SPEAKING_SECS ? '⏹ Stop & Save' : `⏹ Stop (min ${MIN_SPEAKING_SECS}s — wait ${MIN_SPEAKING_SECS-recTime}s)`}
                    </button>
                    <div style={{fontSize:'12px',color:'#6b7280',textAlign:'center',marginBottom:'6px'}}>{recTime>=MIN_SPEAKING_SECS?'Recording in progress…':`Speak for at least ${MIN_SPEAKING_SECS} seconds`}</div>
                    <div style={{height:'4px',background:'#e5e7eb',borderRadius:'2px',overflow:'hidden',marginBottom:'4px',position:'relative'}}>
                      <div style={{height:'100%',background:recTime>=MIN_SPEAKING_SECS?'#16a34a':'#f59e0b',borderRadius:'2px',width:`${(recTime/120)*100}%`,transition:'width 1s linear'}} />
                      <div style={{position:'absolute',top:0,bottom:0,left:`${(MIN_SPEAKING_SECS/120)*100}%`,width:'2px',background:'#9ca3af'}} />
                    </div>
                    <div style={{fontSize:'12px',color:'#9ca3af',textAlign:'center',fontFamily:"'DM Mono',monospace"}}>{fmt(recTime)} / 2:00</div>
                  </>
                )}

                {recState==='recorded' && (
                  <div>
                    <div style={{fontSize:'13px',color:'#16a34a',fontWeight:700,marginBottom:'10px',textAlign:'center'}}>✅ Recording saved — Next is unlocked</div>
                    {attempts < maxAttempts && (
                      <button onClick={()=>setRecState('idle')} style={{width:'100%',padding:'10px',borderRadius:'50px',border:'2px solid #e5e7eb',background:'#fff',color:'#6b7280',fontSize:'13px',cursor:'pointer',fontFamily:font}}>
                        🎙️ Record Again (uses 1 attempt)
                      </button>
                    )}
                  </div>
                )}

                {attempts>=maxAttempts && recState!=='recorded' && (
                  <div style={{padding:'10px 14px',background:'#fffbeb',border:'1px solid #fde68a',borderRadius:'10px',fontSize:'12px',color:'#92400e'}}>⚠️ Maximum attempts reached.</div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer — one-way, no Previous */}
      <div style={{position:'sticky',bottom:0,background:'#fff',borderTop:'1px solid #e5e7eb',padding:'12px 20px',display:'flex',alignItems:'center',justifyContent:'space-between',zIndex:40}}>
        <div style={{width:'120px'}} />
        <div style={{textAlign:'center'}}>
          <div style={{fontSize:'12px',fontWeight:700,color:'#374151'}}>{sec.label}</div>
          <div style={{fontSize:'12px',color:'#9ca3af'}}>{currentIndex+1} / {questions.length}</div>
        </div>
        <div style={{display:'flex',flexDirection:'column',alignItems:'flex-end',gap:'4px',minWidth:'140px'}}>
          {!canNext && (
            <span style={{fontSize:'11px',color:'#f59e0b',fontWeight:600}}>
              {section==='writing'?`Write ${minWords-wordCount} more word${minWords-wordCount!==1?'s':''}`:section==='speaking'?'Record first':''}
            </span>
          )}
          <button onClick={()=>handleNextQuestion()} disabled={!canNext}
            style={{padding:'10px 24px',borderRadius:'50px',border:'none',background:canNext?sec.color:'#e5e7eb',color:canNext?'#fff':'#9ca3af',fontSize:'14px',fontWeight:700,cursor:canNext?'pointer':'not-allowed',fontFamily:font,transition:'all .2s'}}>
            {currentIndex < questions.length-1 ? 'Next →' : 'Complete Section →'}
          </button>
        </div>
      </div>

      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  )
}
