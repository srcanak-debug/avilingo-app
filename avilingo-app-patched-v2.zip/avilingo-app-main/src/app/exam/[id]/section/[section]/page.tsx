'use client'
import { useEffect, useState, useRef, useCallback } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { supabase } from '@/lib/supabase'

const ROLE_SECTION_ORDER: Record<string,string[]> = {
  general:      ['grammar','reading','listening','writing','speaking'],
  flight_deck:  ['grammar','reading','listening','writing','speaking'],
  cabin_crew:   ['grammar','listening','reading','speaking','writing'],
  atc:          ['grammar','listening','reading','speaking','writing'],
  maintenance:  ['grammar','reading','writing','listening','speaking'],
  ground_staff: ['grammar','reading','listening','writing','speaking'],
}

const sectionColors: Record<string,string> = {
  grammar:'#3A8ED0', reading:'#0A8870', writing:'#B8881A', speaking:'#B83040', listening:'#7C3AED'
}

const MIN_SPEAKING_SECONDS = 30

export default function ExamSectionPage() {
  const router = useRouter()
  const params = useParams()
  const examId = params.id as string
  const section = params.section as string

  const [exam, setExam] = useState<any>(null)
  const [questions, setQuestions] = useState<any[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<string,string>>({})
  const [loading, setLoading] = useState(true)
  const [timeLeft, setTimeLeft] = useState(0)
  const [questionTimeLeft, setQuestionTimeLeft] = useState(0)
  const [strikes, setStrikes] = useState(0)
  const [showStrikeModal, setShowStrikeModal] = useState(false)
  const [showTransitionModal, setShowTransitionModal] = useState(false)
  const [wordCount, setWordCount] = useState(0)
  const [recordingState, setRecordingState] = useState<'idle'|'recording'|'recorded'>('idle')
  const [recordingTime, setRecordingTime] = useState(0)
  const [attempts, setAttempts] = useState(0)
  // Listening: 'idle' | 'playing' | 'done' — true single-play lockout
  const [listenState, setListenState] = useState<'idle'|'playing'|'done'>('idle')
  const [saving, setSaving] = useState(false)

  // Section prep (45s countdown before questions)
  const [showSectionPrep, setShowSectionPrep] = useState(true)
  const [prepTimeLeft, setPrepTimeLeft] = useState(45)
  const [prepEarlyReady, setPrepEarlyReady] = useState(false)

  const timerRef = useRef<any>(null)
  const questionTimerRef = useRef<any>(null)
  const recordingTimerRef = useRef<any>(null)
  const prepTimerRef = useRef<any>(null)
  const listenTimerRef = useRef<any>(null)
  const mediaRecorderRef = useRef<any>(null)
  const audioRef = useRef<HTMLAudioElement>(null)
  // PiP webcam
  const videoRef = useRef<HTMLVideoElement>(null)
  const streamRef = useRef<MediaStream|null>(null)

  useEffect(() => { loadExamAndQuestions() }, [])

  // PiP webcam stream
  useEffect(() => {
    let active = true
    navigator.mediaDevices.getUserMedia({ video: true, audio: false })
      .then(stream => {
        if (!active) { stream.getTracks().forEach(t => t.stop()); return }
        streamRef.current = stream
        if (videoRef.current) videoRef.current.srcObject = stream
      })
      .catch(() => {})
    return () => {
      active = false
      streamRef.current?.getTracks().forEach(t => t.stop())
    }
  }, [])

  // Section prep countdown
  useEffect(() => {
    if (!showSectionPrep) return
    prepTimerRef.current = setInterval(() => {
      setPrepTimeLeft(t => {
        if (t <= 1) {
          clearInterval(prepTimerRef.current)
          setShowSectionPrep(false)
          return 0
        }
        // Allow early-ready button after 5s have elapsed (i.e. when t <= 40)
        if (t <= 40) setPrepEarlyReady(true)
        return t - 1
      })
    }, 1000)
    return () => clearInterval(prepTimerRef.current)
  }, [showSectionPrep])

  useEffect(() => {
    document.addEventListener('visibilitychange', handleVisibilityChange)
    document.addEventListener('contextmenu', e => e.preventDefault())
    document.addEventListener('keydown', handleKeyDown)
    window.addEventListener('blur', handleWindowBlur)
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange)
      document.removeEventListener('keydown', handleKeyDown)
      window.removeEventListener('blur', handleWindowBlur)
    }
  }, [strikes])

  function handleVisibilityChange() {
    if (document.hidden) triggerStrike('tab_switch')
  }
  function handleWindowBlur() { triggerStrike('window_blur') }
  function handleKeyDown(e: KeyboardEvent) {
    if ((e.ctrlKey || e.metaKey) && ['c','v','x'].includes(e.key)) e.preventDefault()
  }

  async function triggerStrike(type: string) {
    const newStrikes = strikes + 1
    setStrikes(newStrikes)
    await supabase.from('violations').insert({ exam_id: examId, type, strike_number: newStrikes })
    if (newStrikes >= 3) {
      await supabase.from('exams').update({ status: 'invalidated' }).eq('id', examId)
      router.push(`/exam/${examId}/invalidated`)
      return
    }
    setShowStrikeModal(true)
  }

  async function loadExamAndQuestions() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { router.push('/login'); return }

    const { data: examData } = await supabase
      .from('exams')
      .select('*,exam_templates(*)')
      .eq('id', examId)
      .eq('candidate_id', user.id)
      .single()

    if (!examData || examData.status === 'invalidated') { router.push('/exam'); return }
    setExam(examData)

    const template = examData.exam_templates
    const count = template[`${section}_count`] || 10

    const { data: existingSet } = await supabase
      .from('exam_question_sets')
      .select('*,questions(*)')
      .eq('exam_id', examId)
      .eq('section', section)
      .order('question_order')

    let questionSet = existingSet || []

    if (questionSet.length === 0) {
      const { data: pool } = await supabase
        .from('questions')
        .select('*')
        .eq('section', section)
        .eq('active', true)
        .eq('is_latest', true)
        .limit(count * 3)

      if (!pool?.length) { setLoading(false); return }

      const shuffled = pool.sort(() => Math.random() - 0.5).slice(0, count)
      const inserts = shuffled.map((q, i) => ({
        exam_id: examId, question_id: q.id, section, question_order: i
      }))
      await supabase.from('exam_question_sets').insert(inserts)
      questionSet = inserts.map((ins, i) => ({ ...ins, questions: shuffled[i] }))
    }

    setQuestions(questionSet.map((qs: any) => qs.questions))

    const totalMins = template.time_limit_mins || 90
    setTimeLeft(totalMins * 60)

    if (section === 'writing') {
      const writingMins = template.writing_timer_mins || 3.5
      setQuestionTimeLeft(Math.round(writingMins * 60))
    }

    setLoading(false)
    startGlobalTimer()
  }

  function startGlobalTimer() {
    timerRef.current = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) { clearInterval(timerRef.current); handleSectionComplete(); return 0 }
        return t - 1
      })
    }, 1000)
  }

  function startQuestionTimer(seconds: number) {
    clearInterval(questionTimerRef.current)
    setQuestionTimeLeft(seconds)
    questionTimerRef.current = setInterval(() => {
      setQuestionTimeLeft(t => {
        if (t <= 1) { clearInterval(questionTimerRef.current); handleNextQuestion(true); return 0 }
        return t - 1
      })
    }, 1000)
  }

  useEffect(() => {
    if (!loading && section === 'writing' && exam) {
      const mins = exam.exam_templates?.writing_timer_mins || 3.5
      startQuestionTimer(Math.round(mins * 60))
    }
  }, [currentIndex, loading])

  // Reset per-question state on question change — also kill any running recording timer
  useEffect(() => {
    clearInterval(recordingTimerRef.current)
    setRecordingState('idle')
    setRecordingTime(0)
    setAttempts(0)
    setListenState('idle')
    clearInterval(listenTimerRef.current)
    setWordCount(0)
  }, [currentIndex, showSectionPrep])

  function formatTime(s: number) {
    const m = Math.floor(s / 60)
    const sec = s % 60
    return `${m}:${sec.toString().padStart(2,'0')}`
  }

  function handleAnswer(questionId: string, answer: string) {
    setAnswers(prev => ({ ...prev, [questionId]: answer }))
    if (section === 'writing') setWordCount(answer.trim().split(/\s+/).filter(Boolean).length)
  }

  async function saveAnswer(questionId: string, answer: string) {
    await supabase.from('exam_answers').upsert({
      exam_id: examId, question_id: questionId, section, answer,
      time_spent_ms: 0
    }, { onConflict: 'exam_id,question_id' })
  }

  // canProceed: gates Next for writing (minWords) and speaking (hasRecording)
  function canProceedNext(): boolean {
    if (section === 'writing') {
      const min = exam?.exam_templates?.writing_min_words || 40
      return wordCount >= min
    }
    if (section === 'speaking') {
      return recordingState === 'recorded'
    }
    return true
  }

  function handleNextQuestion(autoAdvance = false) {
    // Writing: auto-advance ignores word count gate
    if (!autoAdvance && !canProceedNext()) return
    const currentQ = questions[currentIndex]
    if (currentQ) saveAnswer(currentQ.id, answers[currentQ.id] || '')
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(i => i + 1)
    } else {
      setShowTransitionModal(true)
    }
  }

  async function handleSectionComplete() {
    setSaving(true)
    for (const q of questions) {
      await saveAnswer(q.id, answers[q.id] || '')
    }
    clearInterval(timerRef.current)
    clearInterval(questionTimerRef.current)

    if (['grammar','reading','listening'].includes(section)) {
      for (const q of questions) {
        const answer = answers[q.id] || ''
        const correct = q.correct_answer?.trim().toLowerCase()
        const given = answer.trim().toLowerCase()
        const score = correct && given === correct ? 1 : 0
        await supabase.from('exam_answers').upsert({
          exam_id: examId, question_id: q.id, section, answer, auto_score: score
        }, { onConflict: 'exam_id,question_id' })
      }
    }

    setSaving(false)
    const template = exam?.exam_templates
    const role = template?.role_profile || 'general'
    const sectionOrder = (ROLE_SECTION_ORDER[role] || ROLE_SECTION_ORDER.general).filter((s: string) => (template?.[`${s}_count`] || 0) > 0)
    const currentSectionIndex = sectionOrder.indexOf(section)
    const nextSection = sectionOrder[currentSectionIndex + 1]

    if (nextSection) {
      setShowTransitionModal(false)
      router.push(`/exam/${examId}/section/${nextSection}`)
    } else {
      await supabase.from('exams').update({ status: 'completed', completed_at: new Date().toISOString() }).eq('id', examId)
      router.push(`/exam/${examId}/complete`)
    }
  }

  // Speaking: start recording timer
  function startSpeakingRecording() {
    const maxAttempts = exam?.exam_templates?.speaking_attempts || 3
    if (attempts >= maxAttempts) return
    setRecordingState('recording')
    setRecordingTime(0)
    setAttempts(a => a + 1)
    clearInterval(recordingTimerRef.current)
    recordingTimerRef.current = setInterval(() => {
      setRecordingTime(t => {
        const maxSecs = 120
        if (t >= maxSecs - 1) {
          clearInterval(recordingTimerRef.current)
          setRecordingState('recorded')
          return maxSecs
        }
        return t + 1
      })
    }, 1000)
  }

  function stopSpeakingRecording() {
    clearInterval(recordingTimerRef.current)
    setRecordingState('recorded')
    const currentQ = questions[currentIndex]
    if (currentQ) handleAnswer(currentQ.id, 'recorded')
  }

  // Listening: simulate audio play with lockout
  function handleListenPlay() {
    if (listenState !== 'idle') return
    setListenState('playing')
    // If there's a real audio element, let it play and lock on 'ended'
    if (audioRef.current) {
      audioRef.current.play()
      return
    }
    // Simulated: 4s fake playback
    listenTimerRef.current = setTimeout(() => setListenState('done'), 4000)
  }

  const currentQ = questions[currentIndex]
  const template = exam?.exam_templates
  const role = template?.role_profile || 'general'
  const sectionOrder = !loading ? (ROLE_SECTION_ORDER[role] || ROLE_SECTION_ORDER.general).filter((s: string) => (template?.[`${s}_count`] || 0) > 0) : []
  const sectionIndex = sectionOrder.indexOf(section)
  const isTimeCritical = timeLeft < 300
  const maxAttempts = template?.speaking_attempts || 3
  const minWords = template?.writing_min_words || 40
  // Derive canNext directly from state — avoids stale closure issues
  const canNext = section === 'writing'
    ? wordCount >= minWords
    : section === 'speaking'
    ? recordingState === 'recorded'
    : true

  if (loading) return (
    <div style={{minHeight:'100vh',background:'#0B1629',display:'flex',alignItems:'center',justifyContent:'center'}}>
      <div style={{color:'#fff',fontFamily:'var(--fb)'}}>Loading questions...</div>
    </div>
  )

  if (!currentQ) return (
    <div style={{minHeight:'100vh',background:'#0B1629',display:'flex',alignItems:'center',justifyContent:'center'}}>
      <div style={{color:'#fff',fontFamily:'var(--fb)',textAlign:'center'}}>
        <div style={{marginBottom:'16px'}}>No questions available for this section.</div>
        <button onClick={handleSectionComplete} style={{padding:'10px 24px',borderRadius:'8px',border:'none',background:'#3A8ED0',color:'#fff',cursor:'pointer',fontFamily:'var(--fb)'}}>Continue →</button>
      </div>
    </div>
  )

  // ── Section Prep Screen (45s) ─────────────────────────────────────────────
  if (showSectionPrep) {
    const prepPct = ((45 - prepTimeLeft) / 45) * 100
    return (
      <div style={{minHeight:'100vh',background:'#0B1629',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--fb)',padding:'20px'}}>
        {/* PiP webcam */}
        <div style={{position:'fixed',top:'16px',left:'16px',zIndex:50}}>
          <div style={{width:'64px',height:'64px',borderRadius:'50%',overflow:'hidden',border:'2px solid rgba(255,255,255,0.2)',background:'#1a2744',position:'relative'}}>
            <video ref={videoRef} autoPlay muted playsInline style={{width:'100%',height:'100%',objectFit:'cover',transform:'scaleX(-1)'}} />
            <span style={{position:'absolute',bottom:0,left:'50%',transform:'translateX(-50%) translateY(2px)',background:'#1AD18A',color:'#fff',fontSize:'8px',fontWeight:800,padding:'1px 6px',borderRadius:'100px'}}>LIVE</span>
          </div>
        </div>

        <div style={{width:'100%',maxWidth:'520px',textAlign:'center'}}>
          <div style={{width:'72px',height:'72px',borderRadius:'50%',background:sectionColors[section]+'25',border:'2px solid '+sectionColors[section]+'50',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'28px',margin:'0 auto 20px'}}>
            {section === 'grammar' ? '📝' : section === 'reading' ? '📖' : section === 'writing' ? '✏️' : section === 'speaking' ? '🎤' : '👂'}
          </div>
          <h2 style={{fontFamily:'var(--fm)',fontSize:'24px',fontWeight:800,color:'#fff',marginBottom:'4px',textTransform:'capitalize'}}>{section} Section</h2>
          <p style={{fontSize:'13.5px',color:'rgba(255,255,255,0.4)',marginBottom:'32px'}}>Read the instructions carefully before your section begins</p>

          <div style={{background:'rgba(255,255,255,0.05)',borderRadius:'16px',padding:'24px',border:'1px solid rgba(255,255,255,0.08)',marginBottom:'24px',textAlign:'left'}}>
            {[
              section === 'grammar' && 'Choose the best answer for each grammar question.',
              section === 'reading' && 'Read each passage carefully before answering.',
              section === 'writing' && `Write at least ${minWords} words per question. Timer runs per question.`,
              section === 'speaking' && `You have ${maxAttempts} recording attempts per question. Minimum 30 seconds per recording.`,
              section === 'listening' && 'Each audio clip plays exactly once. Listen carefully — you cannot replay it.',
              'You cannot go back to a previous question.',
              'Switching tabs or windows counts as a strike.',
            ].filter(Boolean).map((rule, i) => (
              <div key={i} style={{display:'flex',gap:'10px',alignItems:'flex-start',marginBottom:'10px'}}>
                <span style={{color:sectionColors[section],fontSize:'12px',marginTop:'2px',flexShrink:0}}>▸</span>
                <span style={{fontSize:'13.5px',color:'rgba(255,255,255,0.65)',lineHeight:1.5}}>{rule as string}</span>
              </div>
            ))}
          </div>

          {/* Countdown */}
          <div style={{fontSize:'56px',fontWeight:800,color:sectionColors[section],fontFamily:'var(--fm)',lineHeight:1,marginBottom:'6px'}}>{prepTimeLeft}</div>
          <div style={{fontSize:'12px',color:'rgba(255,255,255,0.3)',marginBottom:'16px'}}>seconds until section starts automatically</div>

          {/* Progress bar */}
          <div style={{width:'100%',height:'4px',background:'rgba(255,255,255,0.1)',borderRadius:'2px',overflow:'hidden',marginBottom:'20px'}}>
            <div style={{height:'100%',background:sectionColors[section],borderRadius:'2px',width:`${prepPct}%`,transition:'width 1s linear'}} />
          </div>

          {/* Early-ready button unlocks after 5s */}
          {prepEarlyReady ? (
            <button
              onClick={() => { clearInterval(prepTimerRef.current); setShowSectionPrep(false) }}
              style={{width:'100%',padding:'13px',borderRadius:'10px',border:'none',background:sectionColors[section],color:'#fff',fontSize:'15px',fontWeight:600,cursor:'pointer',fontFamily:'var(--fb)'}}
            >
              I'm Ready — Start Now →
            </button>
          ) : (
            <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:'8px',color:'rgba(255,255,255,0.3)',fontSize:'13px'}}>
              <div style={{width:'14px',height:'14px',borderRadius:'50%',border:'2px solid rgba(255,255,255,0.2)',borderTopColor:'rgba(255,255,255,0.5)',animation:'spin 1s linear infinite'}} />
              Please read the instructions…
            </div>
          )}
        </div>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    )
  }

  // ── Exam Screen ───────────────────────────────────────────────────────────
  return (
    <div style={{minHeight:'100vh',background:'#0B1629',fontFamily:'var(--fb)',display:'flex',flexDirection:'column',userSelect:'none'}}>

      {/* Strike modal */}
      {showStrikeModal && (
        <div style={{position:'absolute',inset:0,background:'rgba(0,0,0,0.85)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000}}>
          <div style={{background:'#1A2744',borderRadius:'16px',padding:'32px',maxWidth:'400px',textAlign:'center',border:'2px solid #EF4444'}}>
            <div style={{fontSize:'36px',marginBottom:'12px'}}>⚠️</div>
            <h3 style={{fontFamily:'var(--fm)',fontSize:'20px',fontWeight:800,color:'#fff',marginBottom:'8px'}}>Warning — Strike {strikes} of 3</h3>
            <p style={{fontSize:'14px',color:'rgba(255,255,255,0.6)',marginBottom:'20px'}}>Focus violation detected. {3-strikes} strike{3-strikes!==1?'s':''} remaining before automatic invalidation.</p>
            <button onClick={()=>setShowStrikeModal(false)} style={{padding:'10px 28px',borderRadius:'8px',border:'none',background:'#3A8ED0',color:'#fff',fontSize:'14px',fontWeight:600,cursor:'pointer',fontFamily:'var(--fb)'}}>I Understand — Continue</button>
          </div>
        </div>
      )}

      {/* Transition modal */}
      {showTransitionModal && (
        <div style={{position:'absolute',inset:0,background:'rgba(0,0,0,0.85)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000}}>
          <div style={{background:'#1A2744',borderRadius:'16px',padding:'32px',maxWidth:'420px',textAlign:'center',border:'1px solid rgba(255,255,255,0.1)'}}>
            <div style={{fontSize:'32px',marginBottom:'12px'}}>🔒</div>
            <h3 style={{fontFamily:'var(--fm)',fontSize:'20px',fontWeight:800,color:'#fff',marginBottom:'8px',textTransform:'capitalize'}}>{section} Section Complete</h3>
            <p style={{fontSize:'14px',color:'rgba(255,255,255,0.6)',marginBottom:'6px'}}>You are about to permanently lock this section.</p>
            <p style={{fontSize:'13px',color:'rgba(255,255,255,0.4)',marginBottom:'24px'}}>You cannot return to this section after confirming.</p>
            <button onClick={handleSectionComplete} disabled={saving} style={{padding:'11px 24px',borderRadius:'8px',border:'none',background:'#3A8ED0',color:'#fff',fontSize:'14px',fontWeight:600,cursor:'pointer',fontFamily:'var(--fb)'}}>
              {saving ? 'Saving...' : 'Confirm & Continue →'}
            </button>
          </div>
        </div>
      )}

      {/* Top bar */}
      <div style={{background:'rgba(255,255,255,0.04)',borderBottom:'1px solid rgba(255,255,255,0.06)',padding:'10px 24px',display:'flex',alignItems:'center',justifyContent:'space-between',flexShrink:0}}>
        <div style={{display:'flex',alignItems:'center',gap:'12px'}}>
          <span style={{fontSize:'12px',fontWeight:700,padding:'3px 10px',borderRadius:'100px',background:sectionColors[section]+'30',color:sectionColors[section],textTransform:'capitalize',border:'1px solid '+sectionColors[section]+'50'}}>{section}</span>
          <span style={{fontSize:'12.5px',color:'rgba(255,255,255,0.35)'}}>Question {currentIndex+1} of {questions.length}</span>
        </div>

        <div style={{display:'flex',alignItems:'center',gap:'16px'}}>
          {section === 'writing' && (
            <span style={{fontSize:'13px',fontWeight:700,color:questionTimeLeft < 60 ? '#EF4444' : '#F59E0B'}}>
              ⏱ {formatTime(questionTimeLeft)}
            </span>
          )}
          <span style={{fontSize:'14px',fontWeight:700,color:isTimeCritical?'#EF4444':'rgba(255,255,255,0.7)'}}>
            {formatTime(timeLeft)}
          </span>
          {strikes > 0 && (
            <span style={{fontSize:'12px',fontWeight:700,color:'#EF4444'}}>⚠️ {strikes}/3 strikes</span>
          )}
        </div>

        <div style={{display:'flex',alignItems:'center',gap:'8px'}}>
          {/* Section progress dots */}
          <div style={{display:'flex',gap:'4px',marginRight:'8px'}}>
            {sectionOrder.map((s: string, i: number) => (
              <div key={s} style={{width:'28px',height:'4px',borderRadius:'2px',background:i<sectionIndex?sectionColors[s]:s===section?sectionColors[s]:'rgba(255,255,255,0.1)',opacity:i<sectionIndex?0.5:1}} />
            ))}
          </div>
          {/* PiP webcam pill */}
          <div style={{width:'40px',height:'40px',borderRadius:'50%',overflow:'hidden',border:'1.5px solid rgba(255,255,255,0.15)',background:'#1a2744',position:'relative',flexShrink:0}}>
            <video ref={videoRef} autoPlay muted playsInline style={{width:'100%',height:'100%',objectFit:'cover',transform:'scaleX(-1)'}} />
            <span style={{position:'absolute',bottom:0,left:'50%',transform:'translateX(-50%) translateY(1px)',background:'#1AD18A',color:'#fff',fontSize:'7px',fontWeight:800,padding:'1px 4px',borderRadius:'100px'}}>LIVE</span>
          </div>
        </div>
      </div>

      {/* Question progress bar */}
      <div style={{height:'3px',background:'rgba(255,255,255,0.06)'}}>
        <div style={{height:'100%',background:sectionColors[section],width:`${((currentIndex+1)/questions.length)*100}%`,transition:'width 0.3s'}} />
      </div>

      {/* Main content */}
      <div style={{flex:1,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'32px 24px'}}>
        <div style={{width:'100%',maxWidth:'720px'}}>

          {/* Question card */}
          <div style={{background:'rgba(255,255,255,0.05)',borderRadius:'14px',padding:'24px',border:'1px solid rgba(255,255,255,0.08)',marginBottom:'20px'}}>
            <div style={{fontSize:'11px',fontWeight:700,color:sectionColors[section],textTransform:'uppercase',letterSpacing:'0.8px',marginBottom:'12px'}}>{section} · Question {currentIndex+1}</div>
            <p style={{fontSize:'16px',color:'#fff',lineHeight:1.7,whiteSpace:'pre-wrap',margin:0}}>{currentQ.content}</p>

            {/* Listening audio — single play */}
            {currentQ.audio_url && section === 'listening' && (
              <div style={{marginTop:'16px'}}>
                <audio
                  ref={audioRef}
                  src={currentQ.audio_url}
                  onEnded={() => setListenState('done')}
                  style={{display:'none'}}
                />
                <div style={{display:'flex',alignItems:'center',gap:'12px',background:'rgba(255,255,255,0.05)',borderRadius:'10px',padding:'12px 16px',border:'1px solid rgba(255,255,255,0.08)'}}>
                  <button
                    onClick={handleListenPlay}
                    disabled={listenState !== 'idle'}
                    style={{width:'44px',height:'44px',borderRadius:'50%',border:'none',background:listenState==='idle'?sectionColors['listening']:'rgba(255,255,255,0.1)',color:'#fff',fontSize:'16px',cursor:listenState==='idle'?'pointer':'not-allowed',flexShrink:0,display:'flex',alignItems:'center',justifyContent:'center'}}
                  >
                    {listenState === 'playing' ? '⏸' : '▶'}
                  </button>
                  <div style={{flex:1}}>
                    {listenState === 'idle' && <div style={{fontSize:'13px',color:'rgba(255,255,255,0.5)'}}>▶ Play once — cannot be replayed</div>}
                    {listenState === 'playing' && <div style={{fontSize:'13px',color:sectionColors['listening']}}>Playing…</div>}
                    {listenState === 'done' && (
                      <div style={{display:'flex',alignItems:'center',gap:'6px'}}>
                        <span style={{fontSize:'12px',fontWeight:700,color:'#EF4444'}}>🔒 Played once — locked</span>
                        <span style={{fontSize:'12px',color:'rgba(255,255,255,0.3)'}}>You cannot replay this audio.</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Answer area */}
          {(section === 'grammar' || section === 'reading') && (
            <div style={{display:'flex',flexDirection:'column',gap:'10px'}}>
              {['A','B','C','D'].map((opt, idx) => {
                const optionText = currentQ.content?.split('\n').find((l: string) => l.startsWith(`${opt}.`) || l.startsWith(`${opt})`))?.replace(/^[A-D][\.\)]\s*/,'')
                if (!optionText && idx >= 2) return null
                const displayText = optionText || `Option ${opt}`
                return (
                  <button key={opt} onClick={()=>handleAnswer(currentQ.id, opt)} style={{padding:'14px 18px',borderRadius:'10px',border:'2px solid',borderColor:answers[currentQ.id]===opt?sectionColors[section]:'rgba(255,255,255,0.08)',background:answers[currentQ.id]===opt?sectionColors[section]+'20':'rgba(255,255,255,0.03)',color:'#fff',fontSize:'14px',cursor:'pointer',fontFamily:'var(--fb)',textAlign:'left',display:'flex',gap:'12px',alignItems:'center',transition:'all 0.15s'}}>
                    <span style={{width:'24px',height:'24px',borderRadius:'50%',border:'1.5px solid',borderColor:answers[currentQ.id]===opt?sectionColors[section]:'rgba(255,255,255,0.2)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'12px',fontWeight:700,flexShrink:0,color:answers[currentQ.id]===opt?sectionColors[section]:'rgba(255,255,255,0.4)'}}>{opt}</span>
                    {displayText}
                  </button>
                )
              })}
            </div>
          )}

          {section === 'listening' && (
            <div style={{display:'flex',flexDirection:'column',gap:'10px'}}>
              {['A','B','C','D'].map((opt) => (
                <button key={opt} onClick={()=>handleAnswer(currentQ.id, opt)} style={{padding:'14px 18px',borderRadius:'10px',border:'2px solid',borderColor:answers[currentQ.id]===opt?sectionColors[section]:'rgba(255,255,255,0.08)',background:answers[currentQ.id]===opt?sectionColors[section]+'20':'rgba(255,255,255,0.03)',color:'#fff',fontSize:'14px',cursor:'pointer',fontFamily:'var(--fb)',textAlign:'left',display:'flex',gap:'12px',alignItems:'center'}}>
                  <span style={{width:'24px',height:'24px',borderRadius:'50%',border:'1.5px solid',borderColor:answers[currentQ.id]===opt?sectionColors[section]:'rgba(255,255,255,0.2)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'12px',fontWeight:700,flexShrink:0,color:answers[currentQ.id]===opt?sectionColors[section]:'rgba(255,255,255,0.4)'}}>{opt}</span>
                  Option {opt}
                </button>
              ))}
            </div>
          )}

          {section === 'writing' && (
            <div>
              <textarea
                value={answers[currentQ.id]||''}
                onChange={e=>handleAnswer(currentQ.id,e.target.value)}
                placeholder="Write your answer here..."
                rows={8}
                style={{width:'100%',padding:'16px',borderRadius:'10px',border:'2px solid',borderColor:wordCount>=minWords?'rgba(26,209,138,0.5)':'rgba(255,255,255,0.1)',background:'rgba(255,255,255,0.05)',color:'#fff',fontSize:'14px',fontFamily:'var(--fb)',resize:'vertical',lineHeight:1.7,outline:'none',boxSizing:'border-box'}}
                onCopy={e=>e.preventDefault()}
                onPaste={e=>e.preventDefault()}
              />
              {/* Word count bar */}
              <div style={{marginTop:'8px'}}>
                <div style={{display:'flex',justifyContent:'space-between',marginBottom:'4px'}}>
                  <span style={{fontSize:'12px',color:wordCount>=minWords?'#1AD18A':'rgba(255,255,255,0.4)'}}>
                    {wordCount} / {minWords} words {wordCount>=minWords ? '✓' : `— ${minWords-wordCount} more needed to unlock Next`}
                  </span>
                  <span style={{fontSize:'12px',color:'rgba(255,255,255,0.3)'}}>Copy/paste disabled</span>
                </div>
                <div style={{height:'3px',background:'rgba(255,255,255,0.1)',borderRadius:'2px',overflow:'hidden'}}>
                  <div style={{height:'100%',background:wordCount>=minWords?'#1AD18A':'#F59E0B',borderRadius:'2px',width:`${Math.min(100,(wordCount/minWords)*100)}%`,transition:'width 0.3s'}} />
                </div>
              </div>
            </div>
          )}

          {section === 'speaking' && (
            <div style={{background:'rgba(255,255,255,0.04)',borderRadius:'12px',padding:'24px',border:'1px solid rgba(255,255,255,0.08)'}}>
              {/* Attempt dots */}
              <div style={{display:'flex',alignItems:'center',gap:'12px',marginBottom:'16px'}}>
                <span style={{fontSize:'12px',color:'rgba(255,255,255,0.4)'}}>Attempts</span>
                <div style={{display:'flex',gap:'6px'}}>
                  {Array.from({length: maxAttempts}, (_, i) => (
                    <div key={i} style={{width:'16px',height:'16px',borderRadius:'50%',border:'2px solid',borderColor:i<attempts?'#B83040':'rgba(255,255,255,0.2)',background:i<attempts?'#B83040':'transparent',display:'flex',alignItems:'center',justifyContent:'center'}}>
                      {i<attempts && <div style={{width:'6px',height:'6px',borderRadius:'50%',background:'#fff'}} />}
                    </div>
                  ))}
                </div>
                <span style={{fontSize:'12px',color:'rgba(255,255,255,0.4)'}}>{attempts}/{maxAttempts} used</span>
              </div>

              <div style={{textAlign:'center'}}>
                {recordingState === 'idle' && attempts < maxAttempts && (
                  <button onClick={startSpeakingRecording} style={{padding:'14px 32px',borderRadius:'100px',border:'2px solid #B83040',background:'transparent',color:'#B83040',fontSize:'15px',fontWeight:600,cursor:'pointer',fontFamily:'var(--fb)'}}>
                    ● Start Recording
                  </button>
                )}

                {recordingState === 'recording' && (
                  <div>
                    <div style={{fontSize:'24px',fontWeight:700,color:'#B83040',fontFamily:'var(--fm)',marginBottom:'8px'}}>● REC {formatTime(recordingTime)}</div>
                    {/* Progress bar — amber until 30s, then green */}
                    <div style={{height:'4px',background:'rgba(255,255,255,0.1)',borderRadius:'2px',overflow:'hidden',marginBottom:'8px',position:'relative'}}>
                      <div style={{height:'100%',background:recordingTime>=MIN_SPEAKING_SECONDS?'#1AD18A':'#F59E0B',borderRadius:'2px',width:`${(recordingTime/120)*100}%`,transition:'width 1s linear'}} />
                      {/* Min marker at 30s */}
                      <div style={{position:'absolute',top:0,bottom:0,width:'2px',background:'rgba(255,255,255,0.3)',left:`${(MIN_SPEAKING_SECONDS/120)*100}%`}} />
                    </div>
                    <button
                      onClick={recordingTime >= MIN_SPEAKING_SECONDS ? stopSpeakingRecording : undefined}
                      disabled={recordingTime < MIN_SPEAKING_SECONDS}
                      style={{padding:'12px 28px',borderRadius:'100px',border:'none',background:recordingTime>=MIN_SPEAKING_SECONDS?'#B83040':'rgba(255,255,255,0.1)',color:'#fff',fontSize:'14px',fontWeight:600,cursor:recordingTime>=MIN_SPEAKING_SECONDS?'pointer':'not-allowed',fontFamily:'var(--fb)'}}
                    >
                      {recordingTime < MIN_SPEAKING_SECONDS
                        ? `Stop available at 0:${String(MIN_SPEAKING_SECONDS).padStart(2,'0')} (${MIN_SPEAKING_SECONDS - recordingTime}s)`
                        : 'Stop & Save'}
                    </button>
                  </div>
                )}

                {recordingState === 'recorded' && (
                  <div>
                    <div style={{fontSize:'14px',color:'#1AD18A',marginBottom:'12px'}}>✓ Recording saved — Next is unlocked</div>
                    {attempts < maxAttempts && (
                      <button onClick={()=>{setRecordingState('idle')}} style={{padding:'10px 20px',borderRadius:'8px',border:'1px solid rgba(255,255,255,0.15)',background:'transparent',color:'rgba(255,255,255,0.5)',fontSize:'13px',cursor:'pointer',fontFamily:'var(--fb)'}}>
                        Re-record (uses 1 attempt)
                      </button>
                    )}
                  </div>
                )}

                {attempts >= maxAttempts && recordingState !== 'recorded' && (
                  <div style={{fontSize:'13px',color:'rgba(255,255,255,0.4)'}}>Maximum attempts reached.</div>
                )}
              </div>
            </div>
          )}

          {/* Navigation — one-way only, no Previous */}
          <div style={{display:'flex',justifyContent:'flex-end',alignItems:'center',marginTop:'20px',gap:'12px'}}>
            {!canNext && (
              <span style={{fontSize:'12px',color:'#F59E0B'}}>
                {section === 'writing' && `Write ${minWords - wordCount} more word${minWords-wordCount!==1?'s':''} to proceed`}
                {section === 'speaking' && 'Record your answer to proceed'}
              </span>
            )}
            <button
              onClick={()=>handleNextQuestion()}
              disabled={!canNext}
              style={{padding:'11px 28px',borderRadius:'9px',border:'none',background:canNext?sectionColors[section]:'rgba(255,255,255,0.1)',color:'#fff',fontSize:'14px',fontWeight:600,cursor:canNext?'pointer':'not-allowed',fontFamily:'var(--fb)',opacity:canNext?1:0.5}}
            >
              {currentIndex < questions.length-1 ? 'Next →' : 'Complete Section →'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
